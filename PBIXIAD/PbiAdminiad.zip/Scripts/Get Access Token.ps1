Login-PowerBI

$accessTokenObject = Get-PowerBIAccessToken
$accessTokenString = Get-PowerBIAccessToken -AsString 

$accessTokenString
